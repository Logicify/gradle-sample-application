package com.logicify.demo.gtp.domain

/**
 * Created by LOGICIFY\corvis on 10/16/14.
 */
class Book {
    String title;
    String author;
    String tags;
    String description;
}
